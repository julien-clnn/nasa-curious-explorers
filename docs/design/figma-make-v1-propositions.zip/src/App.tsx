import { useEffect, useMemo, useState } from "react";
import copy from "./locales/en.json";

type Proposal = "command" | "timeline" | "workbench";
type Metric = "count" | "anomaly";
type Source = "harmonized" | "modis" | "viirs";
type Page = "explorer" | "method" | "benchmark" | "data";

const t = (key: keyof typeof copy) => copy[key];
const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const years = Array.from({ length: 26 }, (_, i) => 2000 + i);
const fmt = new Intl.NumberFormat("en-US");

function Icon({
  name,
  size = 16,
}: {
  name: "sun" | "moon" | "download" | "link" | "chevron" | "close" | "search" | "info";
  size?: number;
}) {
  const paths = {
    sun: (
      <>
        <circle cx="12" cy="12" r="3.5" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
    moon: <path d="M20 15.5A8.2 8.2 0 0 1 8.5 4 8.3 8.3 0 1 0 20 15.5Z" />,
    download: (
      <>
        <path d="M12 3v12m0 0 4-4m-4 4-4-4" />
        <path d="M5 20h14" />
      </>
    ),
    link: (
      <>
        <path d="M9.5 14.5l5-5" />
        <path
          d="M7.2 17.8 5.8 19.2a4.2 4.2 0 0 1-6-6l3.4-3.4a4.2 4.2 0 0 1 5.9 0"
          transform="translate(3 -1)"
        />
        <path
          d="m16.8 6.2 1.4-1.4a4.2 4.2 0 0 1 6 6l-3.4 3.4a4.2 4.2 0 0 1-5.9 0"
          transform="translate(-3 1)"
        />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    close: <path d="m7 7 10 10M17 7 7 17" />,
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="m16 16 4.5 4.5" />
      </>
    ),
    info: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 11v6M12 7.5v.1" />
      </>
    ),
  };
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const valueFor = (year: number, month: number) => {
  const season = [0.44, 0.38, 0.34, 0.37, 0.48, 0.68, 1.08, 1.58, 1.86, 1.42, 0.84, 0.56][month];
  const cycle = 0.82 + ((year * 17 + month * 11) % 39) / 100;
  return Math.round(12350 * season * cycle);
};

function Segmented<T extends string>({
  value,
  items,
  onChange,
  label,
}: {
  value: T;
  items: { value: T; label: string }[];
  onChange: (value: T) => void;
  label: string;
}) {
  return (
    <div className="segmented" role="group" aria-label={label}>
      {items.map((item) => (
        <button
          key={item.value}
          className={value === item.value ? "active" : ""}
          onClick={() => onChange(item.value)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

function Panel({
  title,
  eyebrow,
  actions,
  className = "",
  children,
}: {
  title: string;
  eyebrow?: string;
  actions?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={`panel ${className}`}>
      <header className="panel-head">
        <div>
          {eyebrow && <span className="eyebrow">{eyebrow}</span>}
          <h2>{title}</h2>
        </div>
        {actions && <div className="panel-actions">{actions}</div>}
      </header>
      {children}
    </section>
  );
}

function RegionControls() {
  return (
    <div className="region-controls">
      <label className="search-field">
        <Icon name="search" />
        <span className="sr-only">{t("regionSearch")}</span>
        <input aria-label={t("regionSearch")} defaultValue="Argentina" />
      </label>
      <span className="region-chip">
        Argentina{" "}
        <button aria-label={t("clearRegion")}>
          <Icon name="close" size={13} />
        </button>
      </span>
    </div>
  );
}

function MapPanel({ metric, setMetric }: { metric: Metric; setMetric: (metric: Metric) => void }) {
  return (
    <Panel
      title={t("mapTitle")}
      eyebrow={t("mapEyebrow")}
      className="map-panel"
      actions={
        <Segmented
          value={metric}
          onChange={setMetric}
          label={t("metric")}
          items={[
            { value: "count", label: t("count") },
            { value: "anomaly", label: t("anomaly") },
          ]}
        />
      }
    >
      <RegionControls />
      <div className="map-canvas" role="img" aria-label={t("mapAlt")}>
        <svg viewBox="0 0 660 350" preserveAspectRatio="xMidYMid meet">
          <g className="graticule">
            {[70, 140, 210, 280].map((y) => (
              <path key={y} d={`M0 ${y}H660`} />
            ))}
            {[110, 220, 330, 440, 550].map((x) => (
              <path key={x} d={`M${x} 0V350`} />
            ))}
          </g>
          <g className="land">
            <path d="M68 72 116 43l76 17 45 46-33 28-38-11-17 52-30 7-20-55-36-22Z" />
            <path d="m187 178 39 16 22 43-14 70-29 31-19-67-24-55Z" />
            <path d="m303 76 54-28 81 10 32 25 67-7 53 31-18 35-67 9-35-20-36 27-19 71-39 52-31-30 15-76-28-57-44-11Z" />
            <path d="m540 238 52-12 39 26-21 38-64 2-23-27Z" />
          </g>
          <g className="heat">
            {[
              [205, 210, 18],
              [213, 233, 23],
              [220, 255, 15],
              [394, 205, 24],
              [420, 198, 17],
              [457, 116, 13],
              [501, 139, 20],
              [549, 252, 15],
              [114, 114, 10],
              [169, 88, 14],
            ].map(([cx, cy, r], i) => (
              <circle key={i} cx={cx} cy={cy} r={r} className={`heat-${i % 4}`} />
            ))}
          </g>
          <path className="argentina" d="m211 210 12 17-1 41-14 39-12-41 4-38Z" />
        </svg>
        <div className="zoom">
          <button aria-label="Zoom in">+</button>
          <button aria-label="Zoom out">−</button>
        </div>
        <div className="map-legend">
          <span>{metric === "count" ? "0" : "−50%"}</span>
          <i className={metric} />
          <span>{metric === "count" ? "500+" : "+150%"}</span>
          <small>{metric === "count" ? t("mapUnit") : t("versusNormal")}</small>
        </div>
      </div>
      <footer className="source-line">{t("mapSource")}</footer>
    </Panel>
  );
}

function CalendarHeatmap({
  selected,
  setSelected,
  metric,
}: {
  selected: { year: number; month: number };
  setSelected: (v: { year: number; month: number }) => void;
  metric: Metric;
}) {
  const [table, setTable] = useState(false);
  if (table)
    return (
      <Panel
        title={t("calendarTitle")}
        eyebrow={t("calendarEyebrow")}
        className="calendar-panel"
        actions={
          <button className="text-button" onClick={() => setTable(false)}>
            {t("viewChart")}
          </button>
        }
      >
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>{t("month")}</th>
                <th>{t("hotspots")}</th>
                <th>{t("interval")}</th>
                <th>{t("classification")}</th>
              </tr>
            </thead>
            <tbody>
              {months.map((m, i) => {
                const v = valueFor(selected.year, i);
                return (
                  <tr key={m}>
                    <td>
                      {m} {selected.year}
                    </td>
                    <td>{fmt.format(v)}</td>
                    <td>
                      {fmt.format(Math.round(v * 0.91))}–{fmt.format(Math.round(v * 1.17))}
                    </td>
                    <td>{v > 19000 ? "High" : "Normal"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  return (
    <Panel
      title={t("calendarTitle")}
      eyebrow={t("calendarEyebrow")}
      className="calendar-panel"
      actions={
        <>
          <span className="unit">{metric === "count" ? t("calendarUnit") : t("versusNormal")}</span>
          <button className="text-button" onClick={() => setTable(true)}>
            {t("viewTable")}
          </button>
        </>
      }
    >
      <div className="heatmap-wrap">
        <div className="heatmap" role="grid" aria-label={t("calendarTitle")}>
          <div />
          {months.map((m) => (
            <span className="month-label" key={m}>
              {m}
            </span>
          ))}
          {years.map((year) => (
            <div className="heatmap-row" key={year}>
              <span className="year-label">{year}</span>
              {months.map((_, month) => {
                const value = valueFor(year, month);
                const level =
                  metric === "count"
                    ? Math.min(5, Math.floor(value / 4700))
                    : Math.min(5, Math.max(0, Math.floor((value / valueFor(2016, month)) * 2.3)));
                const isSelected = selected.year === year && selected.month === month;
                const gap = (year === 2001 && month === 2) || (year === 2022 && month === 6);
                return (
                  <button
                    key={month}
                    role="gridcell"
                    title={`${months[month]} ${year}: ${fmt.format(value)} · 80% interval ${fmt.format(Math.round(value * 0.91))}–${fmt.format(Math.round(value * 1.17))}`}
                    className={`heat-cell level-${level} ${isSelected ? "selected" : ""} ${gap ? "gap" : ""}`}
                    onClick={() => setSelected({ year, month })}
                  >
                    <span className="sr-only">
                      {months[month]} {year}: {fmt.format(value)}
                    </span>
                  </button>
                );
              })}
            </div>
          ))}
          <div className="heatmap-row normal-row">
            <span className="year-label">{t("normal")}</span>
            {months.map((_, month) => (
              <i
                key={month}
                className={`heat-cell level-${Math.min(5, 1 + Math.floor(month / 2))}`}
              />
            ))}
          </div>
        </div>
        <div className="sensor-marker">
          <span>{t("converted")}</span>
          <i />
          <span>{t("observed")}</span>
        </div>
      </div>
      <div className="heat-legend">
        <span>{t("lower")}</span>
        {[0, 1, 2, 3, 4, 5].map((n) => (
          <i key={n} className={`level-${n}`} />
        ))}
        <span>{t("higher")}</span>
        <span className="hatched" /> <span>{t("dataGap")}</span>
      </div>
      <footer className="source-line">{t("calendarSource")}</footer>
    </Panel>
  );
}

function KeyFigures() {
  const figures = [
    [t("totalHotspots"), "18,420", "16,900 to 22,100 · 80%"],
    [t("seasonalDifference"), "+62.0%", t("aboveNormal")],
    [t("anomalyClass"), "High", "1.5–3× seasonal normal"],
    [t("seasonRank"), "3rd", t("rankDetail")],
  ];
  return (
    <div className="key-figures">
      {figures.map(([label, value, detail], i) => (
        <article className={`key-figure k${i}`} key={label}>
          <span>{label}</span>
          <strong>{value}</strong>
          <small>{detail}</small>
        </article>
      ))}
    </div>
  );
}

function DailyGrid({
  selected,
  setSelected,
}: {
  selected: { year: number; month: number };
  setSelected: (v: { year: number; month: number }) => void;
}) {
  const days = Array.from({ length: 30 }, (_, i) => i + 1);
  const move = (d: number) => {
    const date = new Date(selected.year, selected.month + d, 1);
    setSelected({ year: date.getFullYear(), month: date.getMonth() });
  };
  return (
    <Panel
      title={`${months[selected.month]} ${selected.year}`}
      eyebrow={t("dailyActivity")}
      className="daily-panel"
      actions={
        <div className="month-nav">
          <button onClick={() => move(-1)} aria-label={t("previousMonth")}>
            <Icon name="chevron" />
          </button>
          <button onClick={() => move(1)} aria-label={t("nextMonth")}>
            <Icon name="chevron" />
          </button>
        </div>
      }
    >
      <div className="weekdays">
        {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
          <span key={i}>{d}</span>
        ))}
      </div>
      <div className="daily-grid">
        {days.map((day) => (
          <div
            key={day}
            className={`day level-${Math.min(5, (day * 7) % 6)} ${day === 9 ? "gap" : ""}`}
          >
            <span>{day}</span>
            <i className={day % 3 === 0 ? "n20" : "snpp"} />
            {day === 9 && <b>{t("noData")}</b>}
          </div>
        ))}
      </div>
      <div className="dot-legend">
        <span>
          <i className="snpp" /> S-NPP
        </span>
        <span>
          <i className="n20" /> NOAA-20
        </span>
        <span className="hatched" /> {t("noData")}
      </div>
    </Panel>
  );
}

function SeasonChart() {
  return (
    <Panel
      title={t("seasonChart")}
      eyebrow={t("yearToDate")}
      className="season-panel"
      actions={<button className="text-button">+ {t("compareYear")}</button>}
    >
      <svg className="chart" viewBox="0 0 680 210" role="img" aria-label={t("seasonAlt")}>
        <g className="chart-grid">
          {[30, 75, 120, 165].map((y) => (
            <path key={y} d={`M45 ${y}H660`} />
          ))}
        </g>
        <path
          className="band"
          d="M45 168 100 161 155 154 210 142 265 130 320 116 375 91 430 64 485 43 540 28 595 18 650 14L650 68 595 76 540 85 485 103 430 122 375 141 320 153 265 162 210 169 155 174 100 178 45 181Z"
        />
        <path
          className="median"
          d="M45 175 100 170 155 165 210 157 265 148 320 136 375 118 430 96 485 77 540 64 595 55 650 49"
        />
        <path
          className="current-line"
          d="M45 176 100 171 155 164 210 155 265 145 320 129 375 108 430 80 485 54"
        />
        <circle className="current-dot" cx="485" cy="54" r="4" />
        <g className="axis-labels">
          {months.map((m, i) => (
            <text key={m} x={48 + i * 54.4} y="202">
              {m}
            </text>
          ))}
        </g>
      </svg>
      <div className="chart-legend">
        <span>
          <i className="line current" /> 2024
        </span>
        <span>
          <i className="line median-line" /> {t("median")}
        </span>
        <span>
          <i className="band-key" /> {t("percentileBand")}
        </span>
      </div>
      <footer className="source-line">{t("seriesSource")}</footer>
    </Panel>
  );
}

function TrendChart() {
  const bars = [
    58, 62, 73, 76, 69, 55, 49, 44, 65, 52, 48, 39, 41, 45, 35, 31, 36, 52, 44, 58, 84, 61, 72, 54,
    48, 39,
  ];
  return (
    <Panel
      title={t("longTerm")}
      eyebrow={t("annualTotals")}
      className="trend-panel"
      actions={<span className="trend-badge">+2.1% {t("perDecade")}</span>}
    >
      <div className="bar-chart">
        {bars.map((h, i) => (
          <i key={i} style={{ height: `${h}%` }} className={i === 24 ? "selected" : ""}>
            <span>{2000 + i}</span>
          </i>
        ))}
      </div>
      <div className="chart-legend">
        <span>
          <i className="bar-key" /> {t("harmonized")}
        </span>
        <span>
          <i className="line trend-line" /> {t("linearTrend")}
        </span>
      </div>
      <footer className="source-line">{t("seriesSource")}</footer>
    </Panel>
  );
}

function SourceControls({
  source,
  setSource,
}: {
  source: Source;
  setSource: (source: Source) => void;
}) {
  return (
    <div className="source-controls">
      <div>
        <span className="control-label">{t("series")}</span>
        <Segmented
          value={source}
          onChange={setSource}
          label={t("source")}
          items={[
            { value: "harmonized", label: t("harmonized") },
            { value: "modis", label: t("modisRaw") },
            { value: "viirs", label: t("viirsRaw") },
          ]}
        />
      </div>
      {source !== "harmonized" && (
        <p className="inline-warning">
          <Icon name="info" /> {t("rawWarning")}
        </p>
      )}
      <div className="export-actions">
        <button className="secondary">
          <Icon name="download" />
          {t("downloadCsv")}
        </button>
        <button className="secondary" onClick={() => navigator.clipboard?.writeText(location.href)}>
          <Icon name="link" />
          {t("copyLink")}
        </button>
      </div>
    </div>
  );
}

function Explorer({
  proposal,
  source,
  setSource,
  metric,
  setMetric,
  selected,
  setSelected,
}: {
  proposal: Proposal;
  source: Source;
  setSource: (s: Source) => void;
  metric: Metric;
  setMetric: (m: Metric) => void;
  selected: { year: number; month: number };
  setSelected: (v: { year: number; month: number }) => void;
}) {
  return (
    <main className={`workspace ${proposal}`}>
      <div className="workspace-intro">
        <div>
          <span className="eyebrow">{t(`proposal.${proposal}.eyebrow` as keyof typeof copy)}</span>
          <h1>{t(`proposal.${proposal}.title` as keyof typeof copy)}</h1>
          <p>{t(`proposal.${proposal}.description` as keyof typeof copy)}</p>
        </div>
        <div className="as-of">
          <span>{t("selectedPeriod")}</span>
          <strong>
            {months[selected.month]} {selected.year}
          </strong>
          <small>{t("updated")}</small>
        </div>
      </div>
      <SourceControls source={source} setSource={setSource} />
      <div className="explorer-grid">
        <MapPanel metric={metric} setMetric={setMetric} />
        <CalendarHeatmap selected={selected} setSelected={setSelected} metric={metric} />
        <KeyFigures />
        <DailyGrid selected={selected} setSelected={setSelected} />
        <SeasonChart />
        <TrendChart />
      </div>
    </main>
  );
}

function ReferencePage({ page }: { page: Exclude<Page, "explorer"> }) {
  if (page === "method")
    return (
      <main className="reference-page">
        <div className="reference-heading">
          <span className="eyebrow">Methodology</span>
          <h1>One continuous record from two different instruments</h1>
          <p>
            MODIS and VIIRS cannot be compared directly. The shipped method converts every valid day
            into VIIRS-equivalent hotspots, then reports its uncertainty.
          </p>
        </div>
        <div className="method-steps">
          {["Aggregate", "Detect outages", "Fit factors", "Validate", "Publish"].map((x, i) => (
            <div key={x}>
              <span>0{i + 1}</span>
              <strong>{x}</strong>
            </div>
          ))}
        </div>
        <div className="reference-grid">
          <Panel title="The conversion factor" eyebrow="Hierarchical shrinkage">
            <div className="formula">
              k = (V + α · k<sub>parent</sub>) / (M + α)
            </div>
            <p className="body-copy">
              Clipped to [k<sub>parent</sub> / 4, k<sub>parent</sub> × 4], with α = 100. Factors
              cascade from world to country, month and 1° cell.
            </p>
          </Panel>
          <Panel title="Validation on unseen years" eyebrow="Median absolute error">
            <table>
              <thead>
                <tr>
                  <th>Test</th>
                  <th>World</th>
                  <th>Country</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>2012</td>
                  <td>1.1%</td>
                  <td>11.3%</td>
                </tr>
                <tr>
                  <td>2020–2025</td>
                  <td>4.0%</td>
                  <td>14.2%</td>
                </tr>
                <tr>
                  <td>Single world ratio</td>
                  <td>8.2%</td>
                  <td>26.6%</td>
                </tr>
              </tbody>
            </table>
          </Panel>
        </div>
      </main>
    );
  if (page === "benchmark")
    return (
      <main className="reference-page">
        <div className="reference-heading">
          <span className="eyebrow">Reproducible benchmark</span>
          <h1>Every parameter is tested out of sample</h1>
          <p>Factors are fitted on 2013–2019 and scored only on years the method has never seen.</p>
        </div>
        <Panel title="Country-month error by α" eyebrow="2020–2025 holdout">
          <div className="parameter-chart">
            {[15.5, 14.1, 14.3, 14.2, 14.5, 15.2, 16].map((v, i) => (
              <div
                key={v}
                className={i === 3 ? "shipped" : ""}
                style={{ height: `${(v - 12) * 18 + 20}px` }}
              >
                <span>{v}%</span>
                <i />
                <small>{[0, 10, 30, 100, 300, 1000, 3000][i]}</small>
              </div>
            ))}
          </div>
          <p className="honest-reading">
            <strong>Honest reading.</strong> α = 100 is shipped because it performs best at the 2012
            junction and remains within 0.1 points of the best country score for 2020–2025.
          </p>
        </Panel>
      </main>
    );
  return (
    <main className="reference-page">
      <div className="reference-heading">
        <span className="eyebrow">Open data</span>
        <h1>Download the record and reproduce the analysis</h1>
        <p>Static, versioned files with stable schemas. Last updated 08 Nov 2026.</p>
      </div>
      <div className="dataset-grid">
        {[
          ["Country daily", "Daily source and harmonized counts", "86 MB"],
          ["Cell monthly", "0.5° gridded monthly activity", "1.2 GB"],
          ["Conversion factors", "All fitted factors by level", "4.8 MB"],
          ["Satellite status", "Detected outages and source choice", "128 KB"],
          ["Validation report", "Predictions, errors and intervals", "14 MB"],
        ].map((d) => (
          <article className="dataset" key={d[0]}>
            <span>CSV · JSON</span>
            <h2>{d[0]}</h2>
            <p>{d[1]}</p>
            <footer>
              <small>{d[2]}</small>
              <button className="secondary">
                <Icon name="download" />
                Download
              </button>
            </footer>
          </article>
        ))}
      </div>
    </main>
  );
}

export default function App() {
  const params = useMemo(() => new URLSearchParams(location.search), []);
  const [proposal, setProposal] = useState<Proposal>(
    (params.get("proposal") as Proposal) || "command",
  );
  const [page, setPage] = useState<Page>((params.get("page") as Page) || "explorer");
  const [source, setSource] = useState<Source>((params.get("source") as Source) || "harmonized");
  const [metric, setMetric] = useState<Metric>((params.get("metric") as Metric) || "count");
  const [selected, setSelected] = useState({
    year: Number(params.get("year")) || 2024,
    month: Number(params.get("month")) || 8,
  });
  const [dark, setDark] = useState(false);
  const [notice, setNotice] = useState(true);

  useEffect(() => {
    const q = new URLSearchParams({
      region: "argentina",
      year: String(selected.year),
      month: String(selected.month),
      source,
      metric,
      method: "hierarchical-v1",
      proposal,
      page,
    });
    history.replaceState(null, "", `?${q}`);
  }, [proposal, page, source, metric, selected]);

  return (
    <div className={dark ? "app dark" : "app"}>
      <div className="proposal-bar">
        <div>
          <span>{t("designReview")}</span>
          <strong>{t("threeDirections")}</strong>
        </div>
        <Segmented
          value={proposal}
          onChange={setProposal}
          label={t("designProposal")}
          items={[
            { value: "command", label: t("proposal.command.short") },
            { value: "timeline", label: t("proposal.timeline.short") },
            { value: "workbench", label: t("proposal.workbench.short") },
          ]}
        />
      </div>
      <header className="topbar">
        <button className="brand" onClick={() => setPage("explorer")}>
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          <span>
            Fire Activity <b>Calendar</b>
          </span>
        </button>
        <nav aria-label={t("primaryNavigation")}>
          {(["explorer", "method", "benchmark", "data"] as Page[]).map((item) => (
            <button
              key={item}
              className={page === item ? "active" : ""}
              onClick={() => setPage(item)}
            >
              {t(`nav.${item}` as keyof typeof copy)}
            </button>
          ))}
        </nav>
        <div className="top-actions">
          <span className="method-pill">
            <i />
            {t("methodName")} <small>v1.0</small>
          </span>
          <button
            className="icon-button"
            onClick={() => setDark(!dark)}
            aria-label={t("themeToggle")}
          >
            <Icon name={dark ? "sun" : "moon"} />
          </button>
        </div>
      </header>
      {notice && (
        <div className="notice">
          <Icon name="info" />
          <span>{t("notice")}</span>
          <button onClick={() => setNotice(false)} aria-label={t("dismiss")}>
            <Icon name="close" />
          </button>
        </div>
      )}
      {page === "explorer" ? (
        <Explorer
          proposal={proposal}
          source={source}
          setSource={setSource}
          metric={metric}
          setMetric={setMetric}
          selected={selected}
          setSelected={setSelected}
        />
      ) : (
        <ReferencePage page={page} />
      )}
    </div>
  );
}
