import { useEffect, useMemo, useState } from "react";

type Metric = "count" | "normal";
type Tab = "calendar" | "trends" | "hotspots" | "about";
type Region = "World" | "Argentina" | "Greenland";
type Granularity = "year" | "month" | "day";
type PanelSize = "closed" | "normal" | "wide";
type Period = { year: number; month: number; day: number; granularity: Granularity };

const fire = [
  "#fff7c2",
  "#ffe08a",
  "#fdba4d",
  "#f4892f",
  "#e0592a",
  "#b8321f",
  "#7e1416",
  "#4a0a0e",
];
const months = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const data: Record<
  Region,
  { count: string; delta: string; normal: string; status: string; rank: string; subtitle: string }
> = {
  World: {
    count: "2.47 M",
    delta: "−6%",
    normal: "2.63 M",
    status: "Normal",
    rank: "19/25",
    subtitle: "19th highest August on record",
  },
  Argentina: {
    count: "113 k",
    delta: "+136%",
    normal: "47.7 k",
    status: "Exceptional",
    rank: "1/25",
    subtitle: "Highest August on record",
  },
  Greenland: {
    count: "991",
    delta: "×90",
    normal: "11",
    status: "Exceptional",
    rank: "1/25",
    subtitle: "Highest August on record",
  },
};

const icons: Record<string, React.ReactNode> = {
  globe: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M3.7 12h16.6M12 3.5c2.7 2.5 4 5.3 4 8.5s-1.3 6-4 8.5c-2.7-2.5-4-5.3-4-8.5s1.3-6 4-8.5Z" />
    </>
  ),
  moon: <path d="M20 15.3A8.5 8.5 0 0 1 8.7 4a8.5 8.5 0 1 0 11.3 11.3Z" />,
  sun: (
    <>
      <circle cx="12" cy="12" r="3.5" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  reset: <path d="M5 7v5h5M6.1 16a7 7 0 1 0 .2-8.2L5 9" />,
  chevron: <path d="m9 18 6-6-6-6" />,
  layers: (
    <>
      <path d="m12 3 9 5-9 5-9-5 9-5Z" />
      <path d="m3 12 9 5 9-5M3 16l9 5 9-5" />
    </>
  ),
  close: <path d="m6 6 12 12M18 6 6 18" />,
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </>
  ),
};

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {icons[name]}
    </svg>
  );
}

function AppBar({
  expert,
  setExpert,
  light,
  setLight,
}: {
  expert: boolean;
  setExpert: (v: boolean) => void;
  light: boolean;
  setLight: (v: boolean) => void;
}) {
  return (
    <header className="appbar">
      <a className="brand" href="#" aria-label="Fire Activity home">
        <span className="brand-mark">
          <i />
          <i />
          <i />
        </span>
        <strong>Fire Activity</strong>
      </a>
      <nav className="main-nav" aria-label="Main navigation">
        <a className="active">Explorer</a>
        <a>Method</a>
        <a>Benchmark</a>
        <a>Data</a>
      </nav>
      <div className="bar-meta">
        FIRMS <span>· Nov 2000 → Dec 2025</span>
      </div>
      <div className="mode-switch">
        <button className={!expert ? "active" : ""} onClick={() => setExpert(false)}>
          Simple
        </button>
        <button className={expert ? "active" : ""} onClick={() => setExpert(true)}>
          Expert
        </button>
      </div>
      <button
        className="icon-button theme-toggle"
        onClick={() => setLight(!light)}
        aria-label="Toggle color theme"
      >
        <Icon name={light ? "moon" : "sun"} size={16} />
      </button>
    </header>
  );
}

function Globe({ region }: { region: Region }) {
  const points = useMemo(
    () =>
      Array.from({ length: region === "World" ? 112 : 68 }, (_, i) => ({
        x: 17 + ((i * 47 + Math.sin(i) * 9) % 67),
        y: 18 + ((i * 31 + Math.cos(i * 2) * 10) % 62),
        s: 1.2 + (i % 4) * 0.48,
        c: fire[2 + (i % 6)],
        delay: (i % 11) * -0.23,
      })),
    [region],
  );
  return (
    <div className={`globe-stage ${region !== "World" ? "zoomed" : ""}`}>
      <div className="starfield" />
      <div className="orbit orbit-a" />
      <div className="orbit orbit-b" />
      <div
        className="earth"
        role="img"
        aria-label={`Night globe showing fire activity in ${region}`}
      >
        <div className="land land-a" />
        <div className="land land-b" />
        <div className="land land-c" />
        <div className="night-sheen" />
        {points.map((p, i) => (
          <i
            className="fire-point"
            key={i}
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: p.s,
              height: p.s,
              background: p.c,
              animationDelay: `${p.delay}s`,
            }}
          />
        ))}
        {region === "Argentina" && <div className="region-outline argentina-outline" />}
        {region === "Greenland" && <div className="region-outline greenland-outline" />}
      </div>
      <div className="location-label">
        {region === "World" ? "Central Africa" : region}
        <span>
          {region === "World"
            ? "4° S · 22° E"
            : region === "Argentina"
              ? "34° S · 64° W"
              : "72° N · 40° W"}
        </span>
      </div>
    </div>
  );
}

function Toolbar({
  region,
  setRegion,
  metric,
  setMetric,
  expert,
  period,
  setPeriod,
}: {
  region: Region;
  setRegion: (r: Region) => void;
  metric: Metric;
  setMetric: (m: Metric) => void;
  expert: boolean;
  period: Period;
  setPeriod: (period: Period) => void;
}) {
  const [periodOpen, setPeriodOpen] = useState(false);
  const periodLabel =
    period.granularity === "year"
      ? String(period.year)
      : period.granularity === "month"
        ? `${monthNames[period.month].slice(0, 3)} ${period.year}`
        : new Intl.DateTimeFormat("en", {
            day: "numeric",
            month: "short",
            year: "numeric",
          }).format(new Date(period.year, period.month, period.day));

  const movePeriod = (direction: -1 | 1) => {
    const date = new Date(period.year, period.month, period.day);
    if (period.granularity === "year") date.setFullYear(date.getFullYear() + direction);
    if (period.granularity === "month") date.setMonth(date.getMonth() + direction);
    if (period.granularity === "day") date.setDate(date.getDate() + direction);
    setPeriod({
      ...period,
      year: Math.min(2025, Math.max(2000, date.getFullYear())),
      month: date.getMonth(),
      day: date.getDate(),
    });
  };

  return (
    <div className="toolbar glass">
      <label className="control region-control">
        <span>Region</span>
        <select value={region} onChange={(e) => setRegion(e.target.value as Region)}>
          <option>World</option>
          <option>Argentina</option>
          <option>Greenland</option>
        </select>
        <small>⌄</small>
      </label>
      <div className="period-control">
        <button aria-label={`Previous ${period.granularity}`} onClick={() => movePeriod(-1)}>
          ‹
        </button>
        <button className="period-label" onClick={() => setPeriodOpen(!periodOpen)}>
          <small>Period</small>
          <strong>{periodLabel}</strong>
        </button>
        <button aria-label={`Next ${period.granularity}`} onClick={() => movePeriod(1)}>
          ›
        </button>
        {periodOpen && (
          <div className="period-popover glass">
            <div className="granularity-tabs">
              {(["year", "month", "day"] as Granularity[]).map((level) => (
                <button
                  key={level}
                  className={period.granularity === level ? "active" : ""}
                  onClick={() => setPeriod({ ...period, granularity: level })}
                >
                  {level[0].toUpperCase() + level.slice(1)}
                </button>
              ))}
            </div>
            <div className="period-fields">
              <label>
                <span>Year</span>
                <select
                  value={period.year}
                  onChange={(e) => setPeriod({ ...period, year: Number(e.target.value) })}
                >
                  {Array.from({ length: 26 }, (_, i) => 2000 + i).map((year) => (
                    <option key={year}>{year}</option>
                  ))}
                </select>
              </label>
              {period.granularity !== "year" && (
                <label>
                  <span>Month</span>
                  <select
                    value={period.month}
                    onChange={(e) => setPeriod({ ...period, month: Number(e.target.value) })}
                  >
                    {monthNames.map((month, i) => (
                      <option key={month} value={i}>
                        {month}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {period.granularity === "day" && (
                <label>
                  <span>Day</span>
                  <select
                    value={period.day}
                    onChange={(e) => setPeriod({ ...period, day: Number(e.target.value) })}
                  >
                    {Array.from(
                      { length: new Date(period.year, period.month + 1, 0).getDate() },
                      (_, i) => i + 1,
                    ).map((day) => (
                      <option key={day}>{day}</option>
                    ))}
                  </select>
                </label>
              )}
            </div>
            <button className="period-apply" onClick={() => setPeriodOpen(false)}>
              Apply period
            </button>
          </div>
        )}
      </div>
      <div className="metric-switch" aria-label="Metric">
        <button className={metric === "count" ? "active" : ""} onClick={() => setMetric("count")}>
          Count
        </button>
        <button className={metric === "normal" ? "active" : ""} onClick={() => setMetric("normal")}>
          vs normal
        </button>
      </div>
      {expert && (
        <button className="more-button" aria-label="Expert settings">
          •••
        </button>
      )}
    </div>
  );
}

function Legend({ metric }: { metric: Metric }) {
  return (
    <div className="legend glass">
      <div className="legend-title">
        <span>{metric === "count" ? "Hotspot density" : "Compared with normal"}</span>
        <b>VIIRS-eq.</b>
      </div>
      <div className="ramp">
        {fire.map((c) => (
          <i key={c} style={{ background: c }} />
        ))}
      </div>
      <div className="ramp-labels">
        <span>{metric === "count" ? "fewer" : "¼×"}</span>
        <span>{metric === "count" ? "more hotspots" : "normal"}</span>
        <span>{metric === "count" ? "" : "4× +"}</span>
      </div>
      <p>Each point = hotspots within ~5 km</p>
    </div>
  );
}

function TimeBar({ playing, setPlaying }: { playing: boolean; setPlaying: (v: boolean) => void }) {
  const ticks = Array.from({ length: 52 }, (_, i) => fire[Math.min(7, 1 + ((i * 7) % 8))]);
  return (
    <div className="timebar glass">
      <button
        className="play"
        onClick={() => setPlaying(!playing)}
        aria-label={playing ? "Pause timeline" : "Play timeline"}
      >
        {playing ? "Ⅱ" : "▶"}
      </button>
      <span className="year first">2000</span>
      <div className="timeline">
        {ticks.map((c, i) => (
          <i key={i} style={{ background: c, opacity: 0.28 + (i % 5) * 0.15 }} />
        ))}
        <div className="viirs-marker">
          <span>VIIRS starts</span>
        </div>
        <div className="time-handle">
          <b>Aug ’20</b>
        </div>
      </div>
      <span className="year">2025</span>
    </div>
  );
}

function CalendarHeatmap({
  region,
  metric,
  period,
  setPeriod,
}: {
  region: Region;
  metric: Metric;
  period: Period;
  setPeriod: (period: Period) => void;
}) {
  const years = Array.from({ length: 26 }, (_, i) => 2000 + i);
  return (
    <div className="calendar-wrap">
      <div className="calendar-heading">
        <div>
          <h3>Fire activity calendar</h3>
          <p>{metric === "count" ? "Monthly hotspot count" : "Monthly count ÷ normal"}</p>
        </div>
        <button>View as table</button>
      </div>
      <div className="calendar-grid" role="grid" aria-label="Fire activity by year and month">
        <div />
        <div className="month-heads">
          {months.map((m, i) => (
            <span key={i}>{m}</span>
          ))}
        </div>
        <span className="year-total-head">Year</span>
        {years.map((y) => {
          const selected = y === period.year;
          return (
            <div className={`calendar-row ${selected ? "selected-year" : ""}`} key={y}>
              <button
                className="year-label"
                onClick={() => setPeriod({ ...period, year: y, granularity: "year" })}
              >
                {y}
              </button>
              <div className="month-cells">
                {months.map((_, m) => {
                  const noData = y === 2000 && m < 10;
                  const sparse = region === "Greenland" && m === 5 && y % 4 === 1;
                  const empty = region === "Greenland" && m !== 7 && !sparse;
                  const selectedCell = selected && m === period.month;
                  const idx =
                    region === "Greenland" ? (selectedCell ? 7 : 0) : 1 + ((y * 3 + m * 5) % 7);
                  return (
                    <button
                      key={m}
                      aria-label={`${monthNames[m]} ${y}`}
                      title={`${monthNames[m]} ${y}`}
                      onClick={() =>
                        setPeriod({ ...period, year: y, month: m, granularity: "month" })
                      }
                      className={`${noData ? "no-data" : empty ? "empty" : sparse ? "sparse" : ""} ${selectedCell ? "selected-cell" : ""}`}
                      style={!noData && !empty && !sparse ? { background: fire[idx] } : undefined}
                    >
                      {sparse && <i />}
                    </button>
                  );
                })}
              </div>
              <div className="year-total">
                <i style={{ width: `${25 + ((y * 11) % 70)}%` }} />
                <span>
                  {region === "Argentina" ? "+" : "−"}
                  {8 + (y % 41)}%
                </span>
              </div>
            </div>
          );
        })}
        <div className="normal-row">
          <b>Normal</b>
          <div>
            {months.map((_, i) => (
              <i key={i} style={{ height: `${20 + ((i * 17) % 75)}%` }} />
            ))}
          </div>
          <span>2.63 M</span>
        </div>
      </div>
      <div className="sensor-divider">
        <span>↑ MODIS converted</span>
        <span>VIIRS observed ↓</span>
      </div>
      <div className="state-key">
        <span>
          <i style={{ background: fire[4] }} />
          Value
        </span>
        <span>
          <i className="empty" />
          No fires
        </span>
        <span>
          <i className="sparse">
            <b />
          </i>
          Too few
        </span>
        <span>
          <i className="no-data" />
          No data
        </span>
      </div>
    </div>
  );
}

function DailyStrip({
  period,
  setPeriod,
}: {
  period: Period;
  setPeriod: (period: Period) => void;
}) {
  const dayCount = new Date(period.year, period.month + 1, 0).getDate();
  return (
    <div className="daily">
      <div className="daily-head">
        <div>
          <h3>
            {monthNames[period.month]} {period.year}
          </h3>
          <p>Daily hotspots · satellite source below</p>
        </div>
        <div>
          <button>‹</button>
          <button>›</button>
        </div>
      </div>
      <div className="days">
        {Array.from({ length: dayCount }, (_, i) => (
          <button
            key={i}
            className={period.granularity === "day" && period.day === i + 1 ? "selected" : ""}
            onClick={() => setPeriod({ ...period, day: i + 1, granularity: "day" })}
          >
            <i style={{ background: fire[1 + ((i * 5) % 7)] }} />
            <span>{i + 1}</span>
            <b className={i % 9 === 0 ? "noaa" : "suomi"} />
          </button>
        ))}
      </div>
      <div className="source-key">
        <span>
          <i className="suomi" />
          Suomi-NPP observed
        </span>
        <span>
          <i className="noaa" />
          NOAA-20 converted
        </span>
      </div>
    </div>
  );
}

function Trends() {
  const bars = [
    36, 42, 39, 55, 48, 63, 58, 70, 51, 62, 78, 67, 84, 72, 92, 76, 86, 95, 79, 88, 71, 98, 89, 100,
    82, 91,
  ];
  return (
    <div className="chart-panel">
      <div className="calendar-heading">
        <div>
          <h3>Annual totals</h3>
          <p>2000–2025 · million VIIRS-eq. hotspots</p>
        </div>
        <button>View as table</button>
      </div>
      <div className="bar-chart">
        {bars.map((h, i) => (
          <i key={i} style={{ height: `${h}%` }} className={i === 23 ? "highlight" : ""} />
        ))}
      </div>
      <div className="chart-axis">
        <span>2000</span>
        <span>2012</span>
        <span>2025</span>
      </div>
      <div className="chart-legend">
        <span>
          <i />
          Harmonized
        </span>
        <span>
          <i />
          VIIRS raw
        </span>
        <span>
          <i />
          MODIS raw
        </span>
      </div>
      <div className="finding">
        <b>2023 finding</b>
        <strong>Canada recorded 10.8× its normal year</strong>
        <p>The highest relative annual activity in the 25-year record.</p>
      </div>
    </div>
  );
}

function Hotspots({ setRegion }: { setRegion: (r: Region) => void }) {
  return (
    <div className="hotspot-list">
      <div className="calendar-heading">
        <div>
          <h3>Most unusual countries</h3>
          <p>August 2020 · compared with normal</p>
        </div>
      </div>
      {[
        ["Argentina", "2.4×", "113 k"],
        ["Peru", "1.9×", "82.4 k"],
        ["Bolivia", "1.7×", "96.1 k"],
        ["Paraguay", "1.5×", "44.8 k"],
      ].map(([name, ratio, count], i) => (
        <button key={name} onClick={() => name === "Argentina" && setRegion("Argentina")}>
          <b>{String(i + 1).padStart(2, "0")}</b>
          <span>
            <strong>{name}</strong>
            <small>{count} hotspots</small>
          </span>
          <em>{ratio}</em>
          <Icon name="chevron" size={16} />
        </button>
      ))}
    </div>
  );
}

function About() {
  return (
    <div className="about-panel">
      <p className="lede">One continuous fire record, without the false 2012 jump.</p>
      <p>
        MODIS counts are converted into what VIIRS would have observed using a hierarchical
        shrinkage model fitted on overlapping years.
      </p>
      <dl>
        <div>
          <dt>World error / month</dt>
          <dd>4.0%</dd>
        </div>
        <div>
          <dt>Country error / month</dt>
          <dd>14.2%</dd>
        </div>
        <div>
          <dt>Method</dt>
          <dd>Hierarchical shrinkage v1.0</dd>
        </div>
      </dl>
      <button className="primary-button">Download this view · CSV</button>
      <a className="text-link">
        Read the complete method <Icon name="chevron" size={14} />
      </a>
    </div>
  );
}

function Inspector({
  region,
  setRegion,
  metric,
  tab,
  setTab,
  panelSize,
  setPanelSize,
  period,
  setPeriod,
}: {
  region: Region;
  setRegion: (r: Region) => void;
  metric: Metric;
  tab: Tab;
  setTab: (t: Tab) => void;
  panelSize: PanelSize;
  setPanelSize: (size: PanelSize) => void;
  period: Period;
  setPeriod: (period: Period) => void;
}) {
  const d = data[region];
  const periodLabel =
    period.granularity === "year"
      ? String(period.year)
      : period.granularity === "month"
        ? `${monthNames[period.month]} ${period.year}`
        : `${period.day} ${monthNames[period.month]} ${period.year}`;
  if (panelSize === "closed")
    return (
      <aside className="inspector closed">
        <button onClick={() => setPanelSize("normal")} aria-label="Open inspector">
          ‹
        </button>
      </aside>
    );
  return (
    <aside className={`inspector ${panelSize}`}>
      <div className="inspector-header">
        <div className="header-kicker">
          <span>
            {region.toUpperCase()} · {periodLabel.toUpperCase()}
          </span>
          <div className="panel-actions">
            <button
              onClick={() => setPanelSize(panelSize === "wide" ? "normal" : "wide")}
              aria-label={panelSize === "wide" ? "Reduce inspector" : "Expand inspector"}
              title={panelSize === "wide" ? "Standard view" : "Detailed view"}
            >
              {panelSize === "wide" ? "↘" : "↖"}
            </button>
            <button
              onClick={() => setPanelSize("closed")}
              aria-label="Close inspector"
              title="Close inspector"
            >
              ›
            </button>
          </div>
        </div>
        <div className="answer">
          <strong>{d.count}</strong>
          <span>
            VIIRS-eq.
            <br />
            hotspots
          </span>
        </div>
        <div className="answer-meta">
          <b className={d.status === "Exceptional" ? "exceptional" : ""}>
            {d.delta} <span>vs normal ({d.normal})</span>
          </b>
          <em>{d.status}</em>
        </div>
        <div className="ranking">
          <span>
            <strong>{d.rank}</strong>
            {d.subtitle}
          </span>
          <Icon name="layers" size={17} />
        </div>
        <p className="provenance">
          Source: Suomi-NPP observed · 31/31 days
          <br />
          Method: Hierarchical shrinkage v1.0
        </p>
      </div>
      <div className="tabs" role="tablist">
        {(["calendar", "trends", "hotspots", "about"] as Tab[]).map((t) => (
          <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
            {t === "about" ? "About" : t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {tab === "calendar" && (
          <>
            <CalendarHeatmap
              region={region}
              metric={metric}
              period={period}
              setPeriod={setPeriod}
            />
            <DailyStrip period={period} setPeriod={setPeriod} />
          </>
        )}
        {tab === "trends" && <Trends />}
        {tab === "hotspots" && <Hotspots setRegion={setRegion} />}
        {tab === "about" && <About />}
        <div className="context-line">
          {region.toLowerCase()} · {periodLabel.toLowerCase()} · hierarchical shrinkage v1.0 · firms
        </div>
      </div>
    </aside>
  );
}

export default function App() {
  const [region, setRegion] = useState<Region>("World");
  const [metric, setMetric] = useState<Metric>("count");
  const [expert, setExpert] = useState(false);
  const [light, setLight] = useState(false);
  const [tab, setTab] = useState<Tab>("calendar");
  const [panelSize, setPanelSize] = useState<PanelSize>("normal");
  const [period, setPeriod] = useState<Period>({
    year: 2020,
    month: 7,
    day: 14,
    granularity: "month",
  });
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams({
      region,
      metric,
      mode: expert ? "expert" : "simple",
      tab,
      period: period.granularity,
      date: `${period.year}-${String(period.month + 1).padStart(2, "0")}-${String(period.day).padStart(2, "0")}`,
    });
    history.replaceState(null, "", `?${params}`);
  }, [region, metric, expert, tab, period]);

  return (
    <main className={`app ${light ? "light" : ""} panel-${panelSize}`}>
      <AppBar expert={expert} setExpert={setExpert} light={light} setLight={setLight} />
      <section className="explorer">
        <div className="map-area">
          <Globe region={region} />
          <Toolbar
            region={region}
            setRegion={setRegion}
            metric={metric}
            setMetric={setMetric}
            expert={expert}
            period={period}
            setPeriod={setPeriod}
          />
          {region !== "World" && (
            <button className="back-world glass" onClick={() => setRegion("World")}>
              ← Back to world
            </button>
          )}
          <Legend metric={metric} />
          <div className="globe-controls glass">
            <button aria-label="Zoom in">
              <Icon name="plus" />
            </button>
            <button aria-label="Zoom out">
              <Icon name="minus" />
            </button>
            <button aria-label="Reset globe">
              <Icon name="reset" />
            </button>
          </div>
          <TimeBar playing={playing} setPlaying={setPlaying} />
        </div>
        <Inspector
          region={region}
          setRegion={setRegion}
          metric={metric}
          tab={tab}
          setTab={setTab}
          panelSize={panelSize}
          setPanelSize={setPanelSize}
          period={period}
          setPeriod={setPeriod}
        />
      </section>
    </main>
  );
}
